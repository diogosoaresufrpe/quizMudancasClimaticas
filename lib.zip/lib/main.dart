import 'package:flutter/material.dart';
import './questionario.dart';
import './resultado.dart';

main() => runApp(PerguntaApp());

class _PerguntaAppState extends State<PerguntaApp> {
  var _perguntaSelecionada = 0;
  var _pontuacaoTotal = 0;
  final _perguntas = const [
    {
      'texto':
          'Assinale a alternativa que contém a principal consequência da grande dependência que os seres humanos têm em relação ao petróleo e ao carvão mineral.?',
      'respostas': [
        {'texto': 'Emissão de CO2 e o aquecimento global.', 'pontuacao': 1},
        {
          'texto': 'Emissão de vapor e aumento das chuvas no planeta',
          'pontuacao': 0
        },
        {
          'texto': 'Alteração da composição da água potável, na Terra',
          'pontuacao': 0
        },
        {
          'texto': 'Aumento da camada de ozônio na estratosfera',
          'pontuacao': 0
        },
      ],
    },
    {
      'texto': 'Entende-se por ilha de calor:',
      'respostas': [
        {
          'texto':
              'O fenômeno climático que ocorre a partir da elevação da temperatura de uma área urbana se comparada a uma zona rural.',
          'pontuacao': 1
        },
        {
          'texto':
              'O fenômeno atmosférico de milhares de metros de espessura que ocorre no topo da camada limite do planeta, a uma altitude da ordem de 1 km.',
          'pontuacao': 0
        },
        {
          'texto':
              'O fenômeno natural de aquecimento térmico da terra, essencial para manter a temperatura do planeta em condições ideais para a sobrevivência dos seres vivos.',
          'pontuacao': 0
        },
        {
          'texto':
              'A poluição do ar, sobretudo em áreas urbanas, por ozônio troposférico e outros compostos originados por reações fotoquímicas.',
          'pontuacao': 0
        },
      ],
    },
    {
      'texto':
          'Problema típico das grandes cidades e muito frequente no inverno. O ar quente, constituído, principalmente, de gases emitidos por automóveis e fábricas e carregado de poluentes, fica retido por uma camada superior de ar frio. O problema descrito acima se refere a (o):',
      'respostas': [
        {'texto': 'Ilhas de Calor', 'pontuacao': 1},
        {'texto': 'Efeito estufa.', 'pontuacao': 0},
        {'texto': 'Inversão térmica', 'pontuacao': 0},
        {'texto': 'Chuvas ácidas', 'pontuacao': 0},
        {'texto': 'El ninho', 'pontuacao': 0},
      ],
    }
  ];

  void _responder(int pontuacao) {
    if (temPerguntaSelecionada) {
      setState(() {
        _perguntaSelecionada++;
        _pontuacaoTotal += pontuacao;
      });
    }
  }

  void _reiniciarQuestionario() {
    setState(() {
      _perguntaSelecionada = 0;
      //_perguntaSelecionada++;
      _pontuacaoTotal = 0;
    });
  }

  bool get temPerguntaSelecionada {
    return _perguntaSelecionada < _perguntas.length;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Mestrado PPGIA - Projeto FPA - Questões'),
        ),
        body: temPerguntaSelecionada
            ? Questionario(
                perguntas: _perguntas,
                perguntaSelecionada: _perguntaSelecionada,
                quantoResponder: _responder,
              )
            : Resultado(_pontuacaoTotal, _reiniciarQuestionario),
      ),
    );
  }
}

class PerguntaApp extends StatefulWidget {
  _PerguntaAppState createState() {
    return _PerguntaAppState();
  }
}
